const Data = [
    {
      id: 1,
      name: 'Basic Tee',
      href: '#',
      imageSrc: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQ2sPvf_ty6w3kDIQWByp_0Enbq5t7J8UcnJ7mLvCAJpn33wCkwRFoQglf6Z9YEVQ5uBo0nLc_VCDck1XcNEbdU9DMj_mQC9VsB3OWVYSVc-e4xpQlIWhZFLQ&usqp=CAE',
      imageAlt: "Front of men's Basic Tee in black.",
      price: '$35',
      color: 'Black',
    },
    
    {
      id: 1,
      name: 'Basic Tee',
      href: '#',
      imageSrc: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQH_9lpTuH7xOWbTnDeESawNllQA-5-Q1Q-w_2oZ2E5S6F-hJ3bmwNmeZg5XlMUzVYfvmUaO57wFbfx0wjGlDkM3cpgvEl2mV9x-SgnI97gkz9Nv4cNn_GOFw&usqp=CAE',
      imageAlt: "Front of men's Basic Tee in black.",
      price: '$35',
      color: 'Black',
    },
    
    {
      id: 1,
      name: 'Basic Tee',
      href: '#',
      imageSrc: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTW3ZOuOcq4hV6Nxj3NEc91o8DjLoOTF0JZeuHtaBeWMzGciMEWX_BaiuUWZRAxg8_eD1DF54qL2-qvE2kI8i2GAwMyxOWdWT7Pz6isalIGouIcx6nUXCXM&usqp=CAE',
      imageAlt: "Front of men's Basic Tee in black.",
      price: '$35',
      color: 'Black',
    },
    
    {
      id: 1,
      name: 'Basic Tee',
      href: '#',
      imageSrc: 'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcTSb9tvPGF12DgsJm_Y47UOGtwVnWW8cDMkuWSef0-UqeT28-UeqoSs0OMhuokIbL_2LloerYx9s68uDBDzEfXPApDFmAo5bSOzsT3O7dI&usqp=CAE',
      imageAlt: "Front of men's Basic Tee in black.",
      price: '$35',
      color: 'Black',
    },
    
  ]

export default Data;